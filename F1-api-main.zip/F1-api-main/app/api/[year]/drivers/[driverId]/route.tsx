import { NextResponse } from "next/server"
import { SITE_URL } from "@/lib/constants"
import { apiNotFound, getLimitAndOffset } from "@/lib/utils"
import { BaseApiResponse } from "@/lib/definitions"
import { db } from "@/db"
import {
  circuits,
  drivers,
  races,
  results,
  sprintRace,
  teams,
} from "@/db/migrations/schema"
import { eq, and, InferModel } from "drizzle-orm"

export const revalidate = 600

interface ApiResponse extends BaseApiResponse {
  season: string | number
  championshipId: string
  driver: InferModel<typeof drivers>
  team: InferModel<typeof teams>
  results: any
}

export async function GET(request: Request, context: any) {
  const queryParams = new URL(request.url).searchParams
  const { limit, offset } = getLimitAndOffset(queryParams)
  try {
    const { year, driverId } = context.params

    const sprintResultsData = await db
      .select({
        raceId: sprintRace.raceId,
        finishingPosition: sprintRace.finishingPosition,
        gridPosition: sprintRace.gridPosition,
        raceTime: sprintRace.raceTime,
        pointsObtained: sprintRace.pointsObtained,
        retired: sprintRace.retired,
      })
      .from(sprintRace)
      .innerJoin(races, eq(sprintRace.raceId, races.raceId))
      .where(
        and(
          eq(sprintRace.driverId, driverId),
          eq(races.championshipId, `f1_${year}`)
        )
      )

    const resultsData = await db
      .select()
      .from(results)
      .innerJoin(races, eq(results.raceId, races.raceId))
      .innerJoin(drivers, eq(results.driverId, drivers.driverId))
      .innerJoin(teams, eq(results.teamId, teams.teamId))
      .innerJoin(circuits, eq(races.circuit, circuits.circuitId))
      //.leftJoin(sprintRace, eq(results.raceId, sprintRace.raceId))
      .where(
        and(
          eq(races.championshipId, `f1_${year}`),
          eq(results.driverId, driverId)
        )
      )
      .orderBy(races.round)
      .limit(limit)
      .offset(offset)

    if (resultsData.length === 0) {
      return apiNotFound(
        request,
        "No results found for this driver and year, try with another one."
      )
    }

    const driver = resultsData.map((row) => {
      return {
        driverId: row.Drivers.driverId,
        name: row.Drivers.name,
        surname: row.Drivers.surname,
        nationality: row.Drivers.nationality,
        birthday: row.Drivers.birthday,
        number: row.Drivers.number,
        shortName: row.Drivers.shortName,
        url: row.Drivers.url,
      }
    })

    const team = resultsData.map((row) => {
      return {
        teamId: row.Teams.teamId,
        teamName: row.Teams.teamName,
        teamNationality: row.Teams.teamNationality,
        firstAppeareance: row.Teams.firstAppeareance,
        constructorsChampionships: row.Teams.constructorsChampionships,
        driversChampionships: row.Teams.driversChampionships,
        url: row.Teams.url,
      }
    })

    const sprintResultsByRaceId = new Map(
      sprintResultsData.map((sprint) => [sprint.raceId, sprint])
    )

    // Procesamos los datos
    const processedData = resultsData.map((row) => {
      const sprintResult = sprintResultsByRaceId.get(row.Races.raceId)

      return {
        race: {
          raceId: row.Races.raceId,
          name: row.Races.raceName,
          round: row.Races.round,
          date: row.Races.raceDate,
          circuit: {
            circuitId: row.Circuits.circuitId,
            name: row.Circuits.circuitName,
            country: row.Circuits.country,
            city: row.Circuits.city,
            length: row.Circuits.circuitLength,
            lapRecord: row.Circuits.lapRecord,
            firstParticipationYear: row.Circuits.firstParticipationYear,
            numberOfCorners: row.Circuits.numberOfCorners,
            fastestLapDriverId: row.Circuits.fastestLapDriverId,
            fastestLapTeamId: row.Circuits.fastestLapTeamId,
            fastestLapYear: row.Circuits.fastestLapYear,
          },
        },
        result: {
          finishingPosition: row.Results.finishingPosition,
          gridPosition: row.Results.gridPosition,
          raceTime: row.Results.raceTime,
          pointsObtained: row.Results.pointsObtained,
          retired: row.Results.retired,
        },
        sprintResult: sprintResult
          ? {
              finishingPosition: sprintResult.finishingPosition,
              gridPosition: sprintResult.gridPosition,
              raceTime: sprintResult.raceTime,
              pointsObtained: sprintResult.pointsObtained,
              retired: sprintResult.retired,
            }
          : null,
      }
    })

    const response: ApiResponse = {
      api: SITE_URL,
      url: request.url,
      limit: limit,
      offset: offset,
      total: processedData.length,
      season: parseInt(year),
      championshipId: `f1_${year}`,
      driver: driver[0],
      team: team[0],
      results: processedData,
    }

    return NextResponse.json(response, {
      headers: {
        "Cache-Control": "public, max-age=600, stale-while-revalidate=60",
      },
      status: 200,
    })
  } catch (error) {
    console.log(error)
    return NextResponse.json({ message: "Server error" }, { status: 500 })
  }
}
